﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WirePort : MonoBehaviour {
    public GameObject Player;
    public GameObject NextNode;
    public int a = 0;
    public float tValue = 0f;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(this.Player.name == collision.name)
        {
            //Portal in sound
            
            a = 1;
        }
        //turn off player control as well
    }
    // Use this for initialization
    void Start () {

	}
	
	// Update is called once per frame
	void Update () {
        Vector3 pos = Player.transform.position;
        if (a == 1)
        {
            //change to electric model
            Player.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Kinematic;
            //Player.userCon
        }
        //Mathf.Lerp(pos, NextNode.transform.postion, .1);
        //bool buff = ((pos.x > NextNode.transform.position.x + .05 || pos.x < NextNode.transform.position.x - .05) && (pos.y > NextNode.transform.position.y + .05 || pos.y > NextNode.transform.position.y - .05));
        if (a == 1)
        {
            Player.transform.position = Lerp(this.transform.position, NextNode.transform.position, tValue);
            tValue += .1f;
            //Player.transform.Translate(Vector3.right * 5.0f * Time.deltaTime);

            /*if(pos.x < NextNode.transform.position.x)
            {
                Player.transform.Translate(Vector3.right * 5.0f * Time.deltaTime);
            }
            if(pos.x > NextNode.transform.position.x)
            {
                Player.transform.Translate(Vector3.left * 5.0f * Time.deltaTime);
            }
            if (pos.y > NextNode.transform.position.y)
            {
                Player.transform.Translate(Vector3.down * 5.0f * Time.deltaTime);
            }
            if (pos.y < NextNode.transform.position.y)
            {
                Player.transform.Translate(Vector3.up * 5.0f * Time.deltaTime);
            }*/

            if (!(pos.x > NextNode.transform.position.x + .5 || pos.x < NextNode.transform.position.x - .5))
            {
                //Debug.Log("AY1");
                if (pos.y == NextNode.transform.position.y)
                {
                    //Player.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;
                    //Debug.Log("AY");
                    tValue = 0f;
                    a = 0;
                }
            }

        }
	}
    Vector3 Lerp(Vector3 a, Vector3 b, float t)
    {
        float xcomp;
        float ycomp;
        float zcomp;
        xcomp = Mathf.Lerp(a.x, b.x, t);
        ycomp = Mathf.Lerp(a.y, b.y, t);
        zcomp = 0;

        return new Vector3(xcomp, ycomp, zcomp);
    }
}
