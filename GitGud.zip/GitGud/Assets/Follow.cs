﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Follow : MonoBehaviour {
    public Transform Player;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    private void LateUpdate()
    {
        Vector3 Pos = Player.transform.position;
        this.transform.position = Pos;
        //this.GetComponent<Rigidbody2D>().position.x =
    }
}
