﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Plunger : MonoBehaviour {
    public int count = 0;
    public bool updown = true;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if(updown == true)
        {
            transform.Translate(Vector3.up * 1.0f * Time.deltaTime);
            count++;
            if(count == 50)
            {
                updown = false;
            }
        } else
        {
            transform.Translate(Vector3.down * 1.0f * Time.deltaTime);
            count--;
            if(count == 0)
            {
                updown = true;
            }
        }
	}
}
