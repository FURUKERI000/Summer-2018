﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Walk : MonoBehaviour {
    public GameObject person;
    //public int Jumping;
    // Use this for initialization
    Rigidbody2D rb;
    Vector3 jump;
    public bool userCon;
	void Start () {
        rb = GetComponent<Rigidbody2D>();
        jump = new Vector3(0f, 2f, 0f);
        userCon = true;
	}

    // Update is called once per frame
    void Update() {
        /*Quaternion rot = person.transform.rotation;
        rot.x = 77;
        //person.transform.rotation = rot;
        //person.transform.position = { 1,2,3};
        var x = Input.GetAxis("Horizontal") * Time.deltaTime * 5.0f;
        //var y = Input.GetAxis("Vertical") * Time.deltaTime * 3.0f;
        var y = 0f;
        if (Input.GetKeyDown(KeyCode.Space)) {
            //y = Input.GetAxis("Vertical") * Time.deltaTime * 3.0f;
            //person.transform.Translate(0, y, 0);
            Vector3 up = transform.TransformDirection(Vector3.up);
            rigidbody.AddForce(up * 5, ForceMode.Impulse);
        }
        else {
            //grav

        }
        person.transform.Translate(x, y, 0);
        */
        //Jumping = 0;
        if(this.GetComponent<Rigidbody2D>().bodyType == RigidbodyType2D.Kinematic)
        {
            userCon = false;
        }
        if (this.GetComponent<Rigidbody2D>().bodyType == RigidbodyType2D.Dynamic)
        {
            userCon = true;
        }
        if (userCon)
        {
            if (Input.GetKey(KeyCode.LeftArrow)) {
                transform.Translate(Vector3.left * 5.0f * Time.deltaTime);
            }
            if (Input.GetKey(KeyCode.RightArrow)) {
                transform.Translate(Vector3.right * 5.0f * Time.deltaTime);
            }
            if (Input.GetKeyDown(KeyCode.Space) & this.GetComponent<Rigidbody2D>().velocity.y == 0) {
                //Jumping = 1;
                //transform.Translate(Vector3.up * 5.0f * Time.deltaTime);
                //Vector3 up = transform.TransformDirection (Vector3.up);
                //this.GetComponent<Rigidbody>().AddForce (up * 5, ForceMode.Impulse);
                //Jumping = 1;
                //transform.Translate(Vector3.up * 50.0f * Time.deltaTime);

                rb.AddForce(jump * 6f, ForceMode2D.Impulse);
            }
            /*else
            {
                //transform.Translate(Vector3.down * 5.0f * Time.deltaTime);
                Vector3 down = transform.TransformDirection(Vector3.down);
                GetComponent<Rigidbody>().AddForce(down * 5, ForceMode.Impulse);
            }*/
        }
    }
    private void LateUpdate()
    {
        
    }
}
