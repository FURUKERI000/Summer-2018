﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TwoWayNN : MonoBehaviour
{
    public GameObject Player;
    public GameObject NextNode1;
    public GameObject NextNode2;
    public GameObject Button1;
    public int a = 0;
    public float tValue = 0f;

    private Button buttonAccess;


    public bool path = true;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (this.Player.name == collision.name)
        {
            //Debug.Log("trues");
            a = 1;
        }
        //turn off player control as well
    }
    // Use this for initialization
    void Start()
    {
        buttonAccess = Button1.GetComponent<Button>();
    }

    // Update is called once per frame
    void Update()
    {
        path = !buttonAccess.OnOff;
        GameObject NextNode;
        if(path)
        {
            NextNode = NextNode1;
        }
        else
        {
            NextNode = NextNode2;
        }

        Vector3 pos = Player.transform.position;
        {
            if (a == 1)
            {
                Player.transform.position = Lerp(this.transform.position, NextNode.transform.position, tValue);
                tValue += .1f;
                if (!(pos.x >= NextNode.transform.position.x + .05 || pos.x <= NextNode.transform.position.x - .05))
                {
                    if (pos.y <= NextNode.transform.position.y + .5 && pos.y >= NextNode.transform.position.y - .5)
                    {
                        tValue = 0f;
                        a = 0;
                    }
                }

            }
        }
    }
    Vector3 Lerp(Vector3 a, Vector3 b, float t)
    {
        float xcomp;
        float ycomp;
        float zcomp;
        xcomp = Mathf.Lerp(a.x, b.x, t);
        ycomp = Mathf.Lerp(a.y, b.y, t);
        zcomp = 0;

        return new Vector3(xcomp, ycomp, zcomp);
    }

    /*void Pushed()
    {
        if(path == true)
        {
            path = false;
        }
        else
        {
            path = true;
        }
    }*/
}