﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Button : MonoBehaviour {
    public GameObject Player;

    public Material mat;
    public Color red;
    public Color green;

    //public int a = 0;
    public bool OnOff;

    //public delegate void ButtonPushed();
    //public static event ButtonPushed Pushed;


    /*private void OnTriggerEnter2D(Collider2D collision)
    {
        if (this.Player.name == collision.name)
        {
            OnOff = true;
            //Debug.Log("true");
        }
    }*/

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (this.Player.name == collision.name)
        {
            OnOff = !OnOff;
            if(mat.color == red)
            {
                mat.color = green;
            } else
            {
                mat.color = red;
            }
        }
    }
    // Use this for initialization
    void Start () {
        mat.color = Color.red;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    /*public bool GetOnOff()
    {
        return OnOff;
    }*/
}
