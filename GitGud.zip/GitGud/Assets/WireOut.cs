﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WireOut : MonoBehaviour {
    public GameObject Player;
    public int a;
    // Use this for initialization
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (this.Player.name == collision.name)
        {

           //Portal out sound
            Debug.Log("trues");
            a = 1;
        }
        //turn off player control as well
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (this.Player.name == other.name)
        {
            a = 0;
        }
    }
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (a == 1)
        {
            
            Player.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;

        }
    }
    Vector3 Lerp(Vector3 a, Vector3 b, float t)
    {
        float xcomp;
        float ycomp;
        float zcomp;
        xcomp = Mathf.Lerp(a.x, b.x, t);
        ycomp = Mathf.Lerp(a.y, b.y, t);
        zcomp = 0;

        return new Vector3(xcomp, ycomp, zcomp);
    }
}
